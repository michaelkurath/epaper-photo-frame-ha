from __future__ import annotations

import asyncio
import hashlib
from pathlib import Path
from urllib.parse import urlparse
from urllib.request import Request, urlopen

from frame_app.config import Settings
from frame_app.image_pipeline import ImagePipeline
from frame_app.models import StoredPhoto
from frame_app.sources.base import PhotoSource
from frame_app.storage import Catalogue


class FrameService:
    def __init__(
        self,
        settings: Settings,
        source: PhotoSource,
        catalogue: Catalogue,
        pipeline: ImagePipeline,
    ) -> None:
        self.settings = settings
        self.source = source
        self.catalogue = catalogue
        self.pipeline = pipeline
        self.original_dir = settings.data_dir / "cache" / "original"
        self.render_dir = settings.data_dir / "cache" / "rendered"
        self.original_dir.mkdir(parents=True, exist_ok=True)
        self.render_dir.mkdir(parents=True, exist_ok=True)
        self._sync_lock = asyncio.Lock()
        self._frame_lock = asyncio.Lock()

    @staticmethod
    def _cache_key(photo_id: str) -> str:
        return hashlib.sha256(photo_id.encode("utf-8")).hexdigest()

    def _paths(self, photo_id: str) -> tuple[Path, Path, Path]:
        key = self._cache_key(photo_id)
        return (
            self.original_dir / f"{key}.image",
            self.render_dir / f"{key}.png",
            self.render_dir / f"{key}.raw",
        )

    @staticmethod
    def _download_url(source_url: str) -> str:
        parsed = urlparse(source_url)
        hostname = parsed.hostname or ""
        if parsed.scheme != "https" or not (
            hostname == "googleusercontent.com"
            or hostname.endswith(".googleusercontent.com")
        ):
            raise ValueError("Image host is not allowed")
        return source_url if "=" in parsed.path.rsplit("/", 1)[-1] else f"{source_url}=w2400-h2400"

    def _download_sync(self, photo: StoredPhoto, destination: Path) -> None:
        request = Request(
            self._download_url(photo.source_url),
            headers={"User-Agent": "ePaperPhotoFrame/0.1"},
        )
        temporary = destination.with_suffix(".tmp")
        try:
            with urlopen(request, timeout=45) as response:
                content_type = response.headers.get("content-type", "")
                if not content_type.startswith("image/"):
                    raise ValueError("Photo download did not return an image")
                total = 0
                with temporary.open("wb") as output:
                    while chunk := response.read(64 * 1024):
                        total += len(chunk)
                        if total > 30 * 1024 * 1024:
                            raise ValueError("Photo exceeds the 30 MiB safety limit")
                        output.write(chunk)
            if total == 0:
                raise ValueError("Photo download was empty")
            temporary.replace(destination)
        except Exception:
            temporary.unlink(missing_ok=True)
            raise

    async def _download(self, photo: StoredPhoto, destination: Path) -> None:
        await asyncio.to_thread(self._download_sync, photo, destination)

    async def _ensure_render(self, photo: StoredPhoto) -> tuple[Path, Path]:
        original, png, raw = self._paths(photo.id)
        if not original.exists():
            await self._download(photo, original)
        if not png.exists():
            await asyncio.to_thread(self.pipeline.render_png, original.read_bytes(), png)
        if not raw.exists():
            await asyncio.to_thread(self.pipeline.png_to_raw, png, raw)
        return png, raw

    async def sync(self) -> dict[str, object]:
        async with self._sync_lock:
            try:
                snapshot = await self.source.fetch()
                self.catalogue.sync(snapshot)
                preview = self.catalogue.preview_photo()
                if preview:
                    await self._ensure_render(preview)
            except Exception as exc:
                safe_error = f"{type(exc).__name__}: synchronization failed"
                self.catalogue.set_state("last_error", safe_error)
                raise
            return self.status()

    async def next_frame(self) -> tuple[StoredPhoto, Path, Path]:
        async with self._frame_lock:
            photo = self.catalogue.choose_next()
            if photo is None:
                raise LookupError("No cached photo is available")
            png, raw = await self._ensure_render(photo)
            self.catalogue.mark_shown(photo.id)
            return photo, png, raw

    async def current_frame(self) -> tuple[StoredPhoto, Path, Path]:
        async with self._frame_lock:
            photo_id = self.catalogue.get_state("current_photo_id")
            photo = self.catalogue.get_photo(photo_id) if photo_id else None
            if photo is None:
                photo = self.catalogue.preview_photo()
            if photo is None:
                raise LookupError("No cached photo is available")
            png, raw = await self._ensure_render(photo)
            return photo, png, raw

    def status(self) -> dict[str, object]:
        status = self.catalogue.status()
        status.update(
            {
                "orientation": self.settings.orientation,
                "width": self.settings.dimensions[0],
                "height": self.settings.dimensions[1],
                "fit_mode": self.settings.fit_mode,
                "dither": self.settings.dither,
            }
        )
        return status

    async def background_sync(self) -> None:
        while True:
            try:
                await self.sync()
            except Exception:
                pass
            await asyncio.sleep(self.settings.album_poll_hours * 3600)
